<?php
    $lang->alert_new_message_arrived = '您收到%d個新訊息。您想要檢視嗎?';
?>
