<?php
    $lang->alert_new_message_arrived = 'Sie haben eine neue Nachricht. Wollen Sie jetzt prüfen, ob?';
?>
