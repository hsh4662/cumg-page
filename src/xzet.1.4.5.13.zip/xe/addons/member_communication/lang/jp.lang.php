<?php
    $lang->alert_new_message_arrived = '%d個の新しいメッセージが届いています。 確認しますか？';
?>
