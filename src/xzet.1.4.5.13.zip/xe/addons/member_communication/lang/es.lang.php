<?php
    $lang->alert_new_message_arrived = 'Usted tiene un nuevo mensaje. Quiere comprobar ahora?';
?>
