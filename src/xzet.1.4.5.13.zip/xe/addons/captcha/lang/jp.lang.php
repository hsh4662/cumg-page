<?php
    $lang->about_captcha = "위 영어 알파벳을 순서대로 입력해 주세요. 대소문자는 구분하지 않습니다.";
	$lang->captcha_reload = '이미지 새로고침';
	$lang->captcha_play = '음성으로 듣기';
	$lang->captcha_denied = '잘못 입력하셨습니다';
?>
