<?php
    $lang->about_captcha = "Please type alphabets above in order. They are not case-sensitive.";
	$lang->captcha_reload = 'Refresh Image';
	$lang->captcha_play = 'Play sound of words';
	$lang->captcha_denied = 'You have typed wrong alphabets.';
?>
