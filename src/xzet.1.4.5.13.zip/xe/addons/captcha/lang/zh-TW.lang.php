<?php
    $lang->about_captcha = "請依序輸入圖片中的文字，不分大小寫。";
	$lang->captcha_reload = '更換';
	$lang->captcha_play = '播放';
	$lang->captcha_denied = '輸入錯誤';
?>
