<?php
    /**
     * @file   addons/mobile/lang/zh-CN.lang.php
     * @author NHN (developers@xpressengine.com) 翻译：guny
     * @brief  手机XE插件简体中文语言包
     **/

    $lang->cmd_go_upper = '上一级';
    $lang->cmd_go_home = '首页';
    $lang->cmd_view_sitemap = '网站地图';
?>
