<?php
    /**
     * @file   addons/mobile/lang/ko.lang.php
     * @author NHN (developers@xpressengine.com)
     * @brief  한국어 언어팩 (기본적인 내용만 수록)
     **/

    // 언어 선택부분 by misol
    $lang->president_lang = 'Дейсвующй язык';
    $lang->select_lang = 'Выбор языка';
    $lang->lang_return = 'Вернуться';

    $lang->cmd_go_upper = 'Вверх';
    $lang->cmd_go_home = 'На главную страницу';
    $lang->cmd_view_sitemap = 'Посмотреть карту сайта';

?>
