<?php
    /**
     * @file   addons/mobile/lang/ko.lang.php
     * @author NHN (developers@xpressengine.com)
     * @brief  English Language Pack (Basic Contents only)
     **/
    // lang select by misol
    $lang->president_lang = 'selected Language';
    $lang->select_lang = 'select Language';
    $lang->lang_return = 'Go Back';

    $lang->cmd_go_upper = 'Upper';
    $lang->cmd_go_home = 'Go Home';
    $lang->cmd_view_sitemap = 'View site map';
?>
