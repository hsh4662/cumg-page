<?php
    /**
     * @file   addons/mobile/lang/jp.lang.php
     * @author NHN (developers@xpressengine.com) 翻訳：ミニミ
     * @brief  日本語言語パッケージ
     **/

    // 言語選択部分 by misol
    $lang->president_lang = '現在言語';
    $lang->select_lang = '言語選択';
    $lang->lang_return = '戻る';

    $lang->cmd_go_upper = '上位メニュー';
    $lang->cmd_go_home = 'トップへ';
    $lang->cmd_view_sitemap = 'サイトマップ';

?>
