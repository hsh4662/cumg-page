<?php
    /**
     * @file   addons/mobile/lang/ko.lang.php
     * @author NHN (developers@xpressengine.com)
     * @brief  한국어 언어팩 (기본적인 내용만 수록)
     **/

    // 언어 선택부분 by misol
    $lang->president_lang = '현재 언어';
    $lang->select_lang = '언어 선택';
    $lang->lang_return = '돌아가기';

    $lang->cmd_go_upper = '상위';
    $lang->cmd_go_home = '홈으로';
    $lang->cmd_view_sitemap = '사이트맵 보기';

?>
