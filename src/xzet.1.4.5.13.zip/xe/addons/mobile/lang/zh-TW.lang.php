<?php
    /**
     * @file   addons/mobile/lang/zh-TW.lang.php
     * @author NHN (developers@xpressengine.com) 翻譯：royallin
     * @brief  XE行動上網正體中文語言
     **/
    // lang select by misol
    $lang->president_lang = '已選擇語言';
    $lang->select_lang = '選擇語言';
    $lang->lang_return = '返回';

    $lang->cmd_go_upper = '回上頁';
    $lang->cmd_go_home = '回首頁';
    $lang->cmd_view_sitemap = '網站地圖';
?>
