<?php
/*			░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
			░░  * @File   :  common/lang/vi.lang.php                                              ░░
			░░  * @Author :  NHN (developers@xpressengine.com)                                                 ░░
			░░  * @Trans  :  Đào Đức Duy (ducduy.dao.vn@vietxe.net)								  ░░
			░░	* @Website:  http://vietxe.net													  ░░
			░░  * @Brief  :  Vietnamese Language Pack (Only basic words are included here)        ░░
			░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░	   		*/
			
    // lang select by misol
    $lang->president_lang = 'Chọn ngôn ngữ';
    $lang->select_lang = 'Chọn ngôn ngữ';
    $lang->lang_return = 'Trở lại';

    $lang->cmd_go_upper = 'Lên trên';
    $lang->cmd_go_home = 'Về trang chủ';
    $lang->cmd_view_sitemap = 'Xem sơ đồ Web';
?>
