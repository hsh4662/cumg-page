<?php
    /**
     * @class WidgetHandler
     * @author NHN (developers@xpressengine.com)
     * @brief Handler class for widget execution
     * @remark it is empty for now, it would be removed in the future
     **/

    class WidgetHandler {

        var $widget_path = '';

    }
?>
