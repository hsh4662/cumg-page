<?php
    /**
     * @class  Handler
     * @author NHN (developers@xpressengine.com)
     * @brief  an abstract class of (*)Handler 
     **/

    class Handler {

    }
?>
