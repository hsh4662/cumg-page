<?php
    /**
     * @archivo   es.lang.php
     * @autor NHN (developers@xpressengine.com)
     * @sumario Paquete del idioma español 
     **/

    $lang->addon = "Addon";

    $lang->addon_info = 'Información de Addon';
    $lang->addon_maker = 'Autor de Addon';
    $lang->addon_license = 'License';
    $lang->addon_history = 'Historia de Addon ';

    $lang->about_addon_mid = "Add-ons se puede utilizar para especificar el destino. <br /> (Todo gratis, están disponibles en todos los destinos)";
    $lang->about_addon = 'Addon is para controlar las acciones y no para mostrar el resultado en HTML.<br /> Sólo con activar o desactivar el addon que desee, podrá obtener funciones útiles para la administración de tu sitio web.';
?>
