<?php
    /**
     * @file   en.lang.php
     * @author NHN (developers@xpressengine.com)
     * @brief  English Language Pack
     **/

    $lang->addon = "Eklentiler";

    $lang->addon_info = 'Eklenti Özeti';
    $lang->addon_maker = 'Eklenti Tasarımcısı';
    $lang->addon_license = 'Lisans';
    $lang->addon_history = 'Eklenti Geçmişi';

    $lang->about_addon_mid = "Eklentiler, hedef seçebilirler.<br />(Herhangi bir seçim yapılmadığında, tüm hedefler seçilecektir.)";
    $lang->about_addon = 'Eklentiler, HTML sonuçlarını göstermek yerine sitenizde gerçekleştirilen birçok eylemi kontrol ederler, .<br />Kullanışlı işlevleri, AÇIK/KAPALI anahtarını değiştirerek, kolayca kontrol edebilirsiniz.';
?>
