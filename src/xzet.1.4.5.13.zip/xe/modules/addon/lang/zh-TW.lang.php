<?php
    /**
     * @file   modules/addon/lang/zh-TW.lang.php
     * @author NHN (developers@xpressengine.com) 翻譯：royallin
     * @brief  附加元件(addon)模組正體中文語言
     **/

    $lang->addon = "附加元件";

    $lang->addon_info = '資料';
    $lang->addon_maker = '作者';
    $lang->addon_license = '版權';
    $lang->addon_history = '更新紀錄';

    $lang->about_addon_mid = "可以指定使用附加元件的目標。<br />(全部不選取表示可用在所有目標。)";
    $lang->about_addon = '附加元件可擴展程式功能，而不是顯示輸出HTML結果。<br />『啟用/禁用』附加元件，以增強網站的功能。';
?>
