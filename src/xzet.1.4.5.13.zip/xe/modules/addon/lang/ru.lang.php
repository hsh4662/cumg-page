<?php
  /**
     * @file   ru.lang.php
     * @author NHN (developers@xpressengine.com) | translation by Maslennikov Evgeny aka X-[Vr]bL1s5 | e-mail: x-bliss[a]tut.by; ICQ: 225035467;
     * @brief  Russian basic language pack
     **/

    $lang->addon = "Аддон";

    $lang->addon_info = 'Информация об аддоне';
    $lang->addon_maker = 'Автор аддона';
    $lang->addon_license = 'License';
    $lang->addon_history = 'История аддона';

    $lang->about_addon_mid = "애드온이 사용될 대상을 지정할 수 있습니다.<br />(모두 해제시 모든 대상에서 사용 가능합니다)";
    $lang->about_addon = 'Аддон служит больше для контролирования действий, чем для отображения HTML-результатов.<br />Простым включением/выключением любых аддонов, Вы можете использовать очень полезные функции для администрирования Вашего веб-сайта';
?>
